import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class App {
    static String[] etudiants = {"Alice Dupont", "Bob Martin", "Charlie Durand", "Diana Leroy", "Eric Petit"};
    static String[] matieres = {"Java", "BDD", "Web", "Réseau", "Cybersécurité"};
    static Map<String, Map<String, Integer>> notes = new HashMap<>();
    static boolean stateMenu = true;
    static Scanner reader = new Scanner(System.in);

    public static void main(String[] args) {
        // Création du dictionnaire imbriqué avec l'étudiant, chaques matières et leurs notes associés

        for (String etudiant : etudiants) {
            Map<String, Integer> notes_etudiants = new HashMap<>();
            for (String matiere : matieres) {
                notes_etudiants.put(matiere, 0);
            }
            notes.put(etudiant, notes_etudiants);
        }
        menuPrincipal();
    }

    public static void menuPrincipal() {
        String menu = """
        1. Saisir les notes
        2. Afficher toutes les notes
        3. Calculer les moyennes
        0. Quitter

        Sélectionnez le numéro du menu.""";

        while (stateMenu) {
            System.out.println(menu);
            int choixMenu = reader.nextInt();

            switch (choixMenu) {
                // Menu saisi de note
                case 0:
                    System.out.println("À bientôt !");
                    System.exit(choixMenu);
                case 1:
                    saisiNoteChoixEtudiant();
                case 2:
                    affichageNoteEleves();
                case 3:
                    calculMoyenne();
            }
        }
    }

    public static void saisiNoteChoixEtudiant() {
        int choixSaisiNote;
        String courantEtudiant;

        System.out.println("Menu saisi de note.\n");
        // Enumération de tous les étudiants
        for (int i = 0; i < etudiants.length; i++) {
            System.out.println(i + 1 + ". " + etudiants[i]);
        }
        System.out.println("0. Retourner en arrière");
        System.out.println("\nVeuillez sélectionner un étudiant: ");

        // Choix de l'étudiant
        choixSaisiNote = reader.nextInt();
        switch(choixSaisiNote) {
            case 0:
                menuPrincipal();
                break;
            case 1:
                courantEtudiant = etudiants[0];
                saisiNoteChoixMatiere(courantEtudiant);
                break;
            case 2:
                courantEtudiant = etudiants[1];
                saisiNoteChoixMatiere(courantEtudiant);
                break;
            case 3:
                courantEtudiant = etudiants[2];
                saisiNoteChoixMatiere(courantEtudiant);
                break;
            case 4:
                courantEtudiant = etudiants[3];
                saisiNoteChoixMatiere(courantEtudiant);
                break;
            case 5:
                courantEtudiant = etudiants[4];
                saisiNoteChoixMatiere(courantEtudiant);
                break;
        }
    }

    public static void saisiNoteChoixMatiere(String etudiant) {
        int choixMatiere;
        String courantMatiere;
        
        System.out.println("Sélectionnez une matière pour " + etudiant);
        affichageMatiere();
        choixMatiere = reader.nextInt();

        switch(choixMatiere) {
            case 0:
                saisiNoteChoixEtudiant();
                break;
            case 1:
                courantMatiere = matieres[0];
                saisiNoteAjoutNoteMatiere(etudiant, courantMatiere);
                break;
            case 2:
                courantMatiere = matieres[1];
                saisiNoteAjoutNoteMatiere(etudiant, courantMatiere);
                break;
            case 3:
                courantMatiere = matieres[2];
                saisiNoteAjoutNoteMatiere(etudiant, courantMatiere);
                break;
            case 4:
                courantMatiere = matieres[3];
                saisiNoteAjoutNoteMatiere(etudiant, courantMatiere);
                break;
            case 5:
                courantMatiere = matieres[4];
                saisiNoteAjoutNoteMatiere(etudiant, courantMatiere);
                break;
        }
    }

    public static void saisiNoteAjoutNoteMatiere(String etudiant, String matiere) {
        int choixNoteMatiere;
        
        System.out.println("Sélectionnez une note en " + matiere + " pour " + etudiant);
        choixNoteMatiere = reader.nextInt();
        notes.get(etudiant).put(matiere, choixNoteMatiere);
        menuPrincipal();
    }

    public static void affichageNoteEleves() {
        for (String etudiant: notes.keySet()) {
            System.out.println("Voici les notes pour " + etudiant + ":");

            for (String matiere : notes.get(etudiant).keySet()) {
                int note = notes.get(etudiant).get(matiere);
                System.out.println(" " + matiere + " : " + note);
            }
        System.out.println();
        }
        menuPrincipal();
    }

    public static void calculMoyenne() {
        int moyenne = 0;
        int nombreMatiere = 0;

        for (String matiere : matieres) {
            nombreMatiere++;
        }

        for (String etudiant: notes.keySet()) {
            for (String matiere : notes.get(etudiant).keySet()) {
                int note = notes.get(etudiant).get(matiere);
                moyenne = moyenne + note;
            }
            System.out.println("Voici la moyenne pour " + etudiant + ": " + moyenne / nombreMatiere);
        }
        System.out.println();
    }

    public static void affichageMatiere() {
        System.out.println("Choix de la matière:\n");
        for (int i = 0; i < matieres.length; i++) {
            System.out.println(i + 1 + ". " + matieres[i]);
        }
        System.out.println("0. Choisir un autre étudiant");
    }
}